require "prawn"

# accept a file to be parsed
# filename = ARGV.first
# screenplay = File.open(filename)
# puts "\nHere's #{filename}:"
# puts "\n#{screenplay.read()}\n\n"
# lineCounter = 0
# File.open(filename) {|f| lineCounter = f.read.count("\n") + 1}
# puts "There are #{lineCounter} lines."
# screenplay.close()

##### MARGINS ######
# In prawn, one point is 1/72 of an inch
#
# Page margins:
# top: 0.5" or 36 prawn
####### top page margin is 0.5" (or three single lines) before the page number. a single blank line separates the page number from the body of the script, which begins with either a CONTINUED or a new shot heading/slug line
# bottom: at least 0.5" or 36 prawn
#
# Action margins: Stage directions and shot headings (slug lines) have a margin of 1.7" of the left and 1.1" on the right. two blank lines precede each shot heading.
# Action should have a left margin of 122.4 prawn, and a right margin of 79.2 prawn. The total width is 576 prawn, so that leaves a width of 374.4
#
# Dialog marigns: dialog has a left margin of 2.7" and a right margin of 2.4"
# Aka a left margin of 194.4, right margin of 172.8; 576 - those is 208.8, so that's the width
#
# Paren: Parenthetical directions within dialog has a left margin of 3.4" and a right margin of 3.1"
# aka a left margin of 244.8, right margin of 223.2, a width of 108
#
# Transitions: scenes transitions such as cut to and fade out have a left margin of 6.0"
# aka left margin of 432 prawn, width of 144 prawn

def print_coordinates
  text "top: #{bounds.top}"
  text "bottom: #{bounds.bottom}"
  text "left: #{bounds.left}"
  text "right: #{bounds.right}"
  move_down 10
  text "absolute top: #{sprintf "%.2f", bounds.absolute_top}"
  text "absolute bottom: #{sprintf "%.2f", bounds.absolute_bottom}"
  text "absolute left: #{sprintf "%.2f", bounds.absolute_left}"
  text "absolute right: #{sprintf "%.2f", bounds.absolute_right}"
end

def print_character (name)
  bounding_box([266,cursor], :width=> 310) do
    text name
  end
end

def print_dialog (line)
  bounding_box([194.4,cursor], :width => 208.8) do
    text line, :inline_format => true
    move_down 12.6
  end
end

def print_action (line)
  bounding_box([122.4,cursor], :width => 374.4) do
    text line, :inline_format => true
    move_down 12.6
  end
end

def print_paren (paren)
  bounding_box([244.8,cursor], :width => 108) do
    text paren, :inline_format => true
  end
end

def print_transition (trans)
  bounding_box([432,cursor], :width => 144) do
    text trans, :inline_format => true
    move_down 12.6 #right?
  end
end

def build_pdf (fountain)
  puts fountain
  Prawn::Document.new(:info => { :Title => "My title", :Author => "Max Jacobson", :Creator => "smashcutapp.com", :CreationDate => Time.now}) do
    font("Courier", :size => 12) do
      #text "Title page"
      #print_coordinates
      #start_new_page


      bounding_box([-36, 720], :width => 576) do # removes default margins. there might be a better way to do this. actual ytop is 756 but i took 36 off because i dont want to leave a top margin after all
        #print_coordinates
        #start_new_page

        stringName = "Maxwell"
        stringDialog = "Lorem ipsum <u>dolor</u> sit amet, consectetur <i>adipisicing</i> elit, sed <b>do</b>."
        stringAction = "Sed ut perspiciatis unde omnis iste natus."
        stringParen = "(lovingly)"
        stringTransition = "FADE IN:"

        print_transition(stringTransition)
        print_action(stringAction)
        print_character(stringName)
        print_dialog(stringDialog)
        print_character(stringName)
        print_dialog(stringDialog)
        print_character(stringName)
        print_paren(stringParen)
        print_dialog(stringDialog)



        #start_new_page
        #print_coordinates
        #start_new_page

        #string = "<page>."
        #options = { :at => [bounds.right - 150, 745], :width => 150, :align => :right, :page_filter => lambda { |pg| pg > 1} }
        #number_pages string, options

      end
    end
  end
end

if __FILE__ == $0
  (build_pdf File.open(ARGV.first).read).render_file "output.pdf"
end
